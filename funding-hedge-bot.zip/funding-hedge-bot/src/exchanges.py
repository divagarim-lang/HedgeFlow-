"""CEX helpers using ccxt (async-capable).

Provides minimal wrappers to:
- fetch funding rate (for supported exchanges)
- place/cancel orders (left as optional, with safety guards)
"""
import ccxt.async_support as ccxt
import asyncio
import logging

logger = logging.getLogger(__name__)


class CEXManager:
    def __init__(self, cfg):
        self.cfg = cfg
        self.exchanges = {}
        self._init_exchanges()

    def _init_exchanges(self):
        # init only exchanges configured
        if "binance" in self.cfg:
            self.exchanges["binance"] = ccxt.binance({
                "apiKey": self.cfg["binance"].get("apiKey"),
                "secret": self.cfg["binance"].get("secret"),
                "enableRateLimit": True,
            })
        if "bybit" in self.cfg:
            self.exchanges["bybit"] = ccxt.bybit({
                "apiKey": self.cfg["bybit"].get("apiKey"),
                "secret": self.cfg["bybit"].get("secret"),
                "enableRateLimit": True,
            })

    async def fetch_funding_rate(self, exchange_name, symbol):
        ex = self.exchanges.get(exchange_name)
        if not ex:
            return None
        try:
            # Many CEXs have a fetchFundingRate or fetch_markets + fetch funding via public endpoints
            if hasattr(ex, "fetch_funding_rate"):
                rate = await ex.fetch_funding_rate(symbol)
                return rate
            # fallback: fetch ticker or funding history - this is exchange specific
            markets = await ex.load_markets()
            # placeholder: return None
            return None
        except Exception as e:
            logger.exception("Error fetching funding from %s: %s", exchange_name, e)
            return None

    async def fetch_funding_rates(self, exchange_names, symbol):
        tasks = [self.fetch_funding_rate(name, symbol) for name in exchange_names]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        out = {}
        for name, res in zip(exchange_names, results):
            out[name] = res
        return out

    def find_best_funding_diff(self, funding_dict):
        # funding_dict: {exchange: funding_info}
        # This function should compute the funding differential between exchanges.
        # For the starter, we'll look for numeric rates and compute max-min.
        vals = {}
        for k, v in funding_dict.items():
            try:
                # v might be dict with 'fundingRate' key depending on implementation
                if v is None:
                    continue
                rate = None
                if isinstance(v, dict):
                    rate = v.get("fundingRate") or v.get("rate")
                elif isinstance(v, (int, float)):
                    rate = float(v)
                if rate is None:
                    continue
                vals[k] = float(rate)
            except Exception:
                continue

        if len(vals) < 2:
            return None

        # find max and min
        max_ex = max(vals, key=vals.get)
        min_ex = min(vals, key=vals.get)
        diff = vals[max_ex] - vals[min_ex]
        return {
            "long_exchange": min_ex,  # where funding is lower (you go long perp)
            "short_exchange": max_ex,  # where funding is higher (you go short perp)
            "long_rate": vals[min_ex],
            "short_rate": vals[max_ex],
            "diff": diff,
            "symbol": symbol if (symbol := self.cfg.get("trading", {}).get("symbol")) else None,
        }

    async def close(self):
        for ex in self.exchanges.values():
            await ex.close()
