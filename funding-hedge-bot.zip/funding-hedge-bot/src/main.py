"""Entry point for Funding Hedge Bot - minimal, safe starter.

This script demonstrates the skeleton flow:
- load config
- fetch funding rates from CEXs
- calculate opportunity
- simulate hedged trade (no real orders by default)
"""
import asyncio
import logging
from pathlib import Path

from src.exchanges import CEXManager
from src.hedge import Hedger
from src.utils import load_config

logging.basicConfig(level=logging.INFO)


async def main():
    cfg_path = Path("config.json") if Path("config.json").exists() else Path("config.example.json")
    cfg = load_config(cfg_path)

    cex = CEXManager(cfg)
    hedger = Hedger(cfg)

    try:
        # fetch funding rates
        funding = await cex.fetch_funding_rates(["binance", "bybit"], cfg["trading"]["symbol"])
        print("Funding rates:", funding)

        # compute best arbitrage candidate
        candidate = cex.find_best_funding_diff(funding)
        if not candidate:
            print("No arbitrage candidate found.")
            return

        print("Candidate:", candidate)

        # simulate hedged execution (dry-run by default)
        result = await hedger.execute_hedged_trade(candidate, dry_run=True)
        print("Hedge execution result:", result)
    finally:
        await cex.close()


if __name__ == "__main__":
    asyncio.run(main())
