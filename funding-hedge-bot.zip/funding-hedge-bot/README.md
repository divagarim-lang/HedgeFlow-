# Funding Hedge Bot

This repository is a starter template for a **funding arbitrage + hedge** bot operating across CEX and DEX.

**Warning:** This is educational starter code. Do **not** run with real API keys or capital without thorough testing, security audits, and compliance checks.

## What's included
- `src/` - minimal Python implementation (async) using `ccxt` for CEX access
- `config.example.json` - example configuration (do not store real keys in the repo)
- `requirements.txt` - python dependencies
- `tests/` - basic test scaffold

## Quickstart
1. Copy `config.example.json` to `config.json` and fill your keys (or use environment variables/secret manager).

2. Create a virtualenv and install deps:

   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. Run the bot in dry-run mode:

   ```bash
   python -m src.main
   ```

## Notes / Next steps
- Implement robust sizing, margin checks, leverage handling, and precise funding timing.
- Add backtesting and simulation before any live deployment.
- Never commit real keys; use a secrets manager or environment variables.
